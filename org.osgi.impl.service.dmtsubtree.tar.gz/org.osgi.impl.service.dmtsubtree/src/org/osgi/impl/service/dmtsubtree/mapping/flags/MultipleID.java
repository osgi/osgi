package org.osgi.impl.service.dmtsubtree.mapping.flags;

/**
 * This is a flag interface for the registration of the generated multiple ids. 
 * @author steffen
 *
 */
public interface MultipleID {

}
