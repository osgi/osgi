package org.osgi.impl.service.dmtsubtree.mapping.flags;

/**
 * This is a flag interface used to register mapped pathes.
 * @author steffen
 *
 */
public interface MappedPath {

}
